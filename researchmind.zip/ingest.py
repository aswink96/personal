import os
import sys
import time
from pathlib import Path
from collections import defaultdict
from tqdm import tqdm

from langchain_community.document_loaders import PyPDFLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_community.vectorstores import Chroma
from langchain_community.embeddings import HuggingFaceEmbeddings

sys.path.insert(0, os.path.dirname(__file__))
from config.settings import (
    PDF_DIR, CHROMA_PATH, CHROMA_COLLECTION,
    CHUNK_SIZE, CHUNK_OVERLAP,
    EMBEDDING_MODEL, EMBEDDING_DEVICE
)


def load_all_pdfs(pdf_dir: str) -> list:
    pdf_files = list(Path(pdf_dir).glob("*.pdf"))

    if not pdf_files:
        print(f"❌ No PDFs found in '{pdf_dir}'")
        sys.exit(1)

    print(f"\n📂 Found {len(pdf_files)} PDFs in '{pdf_dir}'")

    docs    = []
    skipped = []

    for pdf_path in tqdm(pdf_files, desc="Loading PDFs", unit="file"):
        try:
            loader = PyPDFLoader(str(pdf_path))
            pages  = loader.load()
            for page in pages:
                page.metadata["filename"] = pdf_path.name
            docs.extend(pages)
        except Exception as e:
            skipped.append(pdf_path.name)
            tqdm.write(f"  ⚠️  Skipping {pdf_path.name}: {e}")

    print(f"\n✅ Loaded {len(docs)} pages from {len(pdf_files)} PDFs")
    if skipped:
        print(f"⚠️  Skipped {len(skipped)} files: {', '.join(skipped)}")

    return docs


def chunk_documents(docs: list) -> list:
    splitter = RecursiveCharacterTextSplitter(
        chunk_size      = CHUNK_SIZE,
        chunk_overlap   = CHUNK_OVERLAP,
        separators      = ["\n\n", "\n", ".", " "],
        length_function = len,
    )

    chunks = splitter.split_documents(docs)

    # ── Attach chunk_index per (filename, page) — needed for ChromaFS cat ──
    # chunk_index lets us reassemble a full page from its chunks in order.
    counters = defaultdict(int)
    clean    = []

    for c in chunks:
        try:
            text = str(c.page_content).strip()
            if len(text) < 30:
                continue
            ascii_ratio = sum(1 for ch in text if ord(ch) < 128) / len(text)
            if ascii_ratio < 0.6:
                continue
            text = "".join(ch for ch in text if ch.isprintable())
            if len(text) < 30:
                continue

            c.page_content = text

            # Assign chunk_index scoped to (filename, page)
            key = (c.metadata.get("filename", ""), c.metadata.get("page", 0))
            c.metadata["chunk_index"] = counters[key]
            counters[key] += 1

            clean.append(c)
        except Exception:
            continue

    print(f"\n✂️  Chunks: {len(clean)} (filtered {len(chunks) - len(clean)} bad)")
    return clean


def build_chroma_index(chunks: list) -> Chroma:
    print(f"🔢 Loading embedding model: {EMBEDDING_MODEL}")
    print(f"   Device: {EMBEDDING_DEVICE.upper()}\n")

    embeddings = HuggingFaceEmbeddings(
        model_name    = EMBEDDING_MODEL,
        model_kwargs  = {"device": EMBEDDING_DEVICE},
        encode_kwargs = {"normalize_embeddings": True},
    )

    # ── Clean chunks ──────────────────────────────────────────────
    safe_chunks = []
    for c in chunks:
        try:
            text = c.page_content
            if not isinstance(text, str) or len(text.strip()) < 30:
                continue
            c.page_content = text.strip()
            safe_chunks.append(c)
        except Exception:
            continue

    print(f"✅ Safe chunks: {len(safe_chunks)}\n")

    # ── Embed in batches of 200 into ChromaDB ─────────────────────
    BATCH_SIZE = 200
    skipped    = 0
    embedded   = 0
    start      = time.time()

    os.makedirs(CHROMA_PATH, exist_ok=True)

    # Create/overwrite the Chroma collection
    vectorstore = None

    print(f"🧠 Embedding {len(safe_chunks)} chunks into ChromaDB...")

    for i in tqdm(range(0, len(safe_chunks), BATCH_SIZE), desc="Embedding"):
        batch = [
            c for c in safe_chunks[i : i + BATCH_SIZE]
            if isinstance(c.page_content, str) and len(c.page_content.strip()) >= 30
        ]
        if not batch:
            continue

        try:
            if vectorstore is None:
                vectorstore = Chroma.from_documents(
                    documents   = batch,
                    embedding   = embeddings,
                    persist_directory = CHROMA_PATH,
                    collection_name   = CHROMA_COLLECTION,
                    collection_metadata = {"hnsw:space": "l2"},  # L2 distance — lower = better
                )
            else:
                vectorstore.add_documents(batch)
            embedded += len(batch)
        except Exception as e:
            tqdm.write(f"   ❌ Batch {i // BATCH_SIZE + 1} failed: {e}")
            skipped += 1

    elapsed = time.time() - start

    if vectorstore is None:
        raise ValueError("❌ No valid chunks embedded. Check your PDFs.")

    print(f"\n✅ Embedded : {embedded} chunks in {elapsed:.1f}s")
    print(f"   Skipped  : {skipped} batches")
    print(f"💾 ChromaDB saved to '{CHROMA_PATH}' (collection: {CHROMA_COLLECTION})")

    return vectorstore


if __name__ == "__main__":
    print("=" * 55)
    print("  test_rag_pipeline — ChromaFS Ingestion Pipeline")
    print("  Embedding : BAAI/bge-small-en-v1.5 (GPU)")
    print("  Storage   : ChromaDB (local, persistent)")
    print("  Cost      : $0.00")
    print("=" * 55)

    start_total = time.time()

    docs   = load_all_pdfs(PDF_DIR)
    chunks = chunk_documents(docs)
    build_chroma_index(chunks)

    total = time.time() - start_total
    print(f"\n⏱️  Total time: {total:.1f}s")