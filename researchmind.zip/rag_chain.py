# rag_chain.py
# ─────────────────────────────────────────────────────────────────────
# PURPOSE: The core RAG pipeline — history-aware.
#
#          User query + chat history
#              ↓
#          Contextualize → rewrites follow-up into standalone question
#              ↓
#          Retriever → finds top-K relevant chunks via FAISS (MMR)
#              ↓
#          format_docs → formats chunks with source + page citations
#              ↓
#          Prompt → combines history + context + question into LLM prompt
#              ↓
#          Ollama (mistral, local) → generates grounded answer
#              ↓
#          StrOutputParser → returns clean string
#
# Run directly to test:  python rag_chain.py
# Used by:               agent/tools.py, api/main.py
# ─────────────────────────────────────────────────────────────────────

import os
import re
import sys

from langchain_ollama import ChatOllama
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import RunnableLambda
from langchain_core.output_parsers import StrOutputParser

sys.path.insert(0, os.path.dirname(__file__))
from retriever import load_retriever, retrieve_with_scores
from config.settings import OLLAMA_MODEL, OLLAMA_BASE_URL, OLLAMA_TEMPERATURE, RELEVANCE_THRESHOLD

# ─────────────────────────────────────────────────────────────────────
# CONTEXTUALIZE PROMPT
# Rewrites a follow-up question into a standalone question using history.
# Example:
#   History: Q: "Who was Akbar?"  A: "Akbar was the third Mughal emperor..."
#   Follow-up: "How many wives did he have?"
#   Rewritten: "How many wives did Akbar have?"
# ─────────────────────────────────────────────────────────────────────
CONTEXTUALIZE_PROMPT = ChatPromptTemplate.from_template("""\
You are a helpful assistant. Given the chat history below and a follow-up question,
rewrite the follow-up question as a fully self-contained, standalone question.
If the question is already standalone, return it unchanged.
Return ONLY the rewritten question, no explanation.

Chat History:
{history}

Follow-up question: {question}

Standalone question:""")


# ─────────────────────────────────────────────────────────────────────
# PRE-RETRIEVAL EXPANDER PROMPT
# Runs BEFORE retrieval for bare numbers or very short queries.
# Example: "1857" → "What happened during the Indian Rebellion of 1857?"
#          "akbar" → "Who was Akbar and what is he known for?"
# ─────────────────────────────────────────────────────────────────────
EXPANDER_PROMPT = ChatPromptTemplate.from_template("""\
A user typed a very short or numeric query into a search engine about Indian history and research papers.
Expand it into a clear, specific, searchable question that captures the most likely intent.
Return ONLY the expanded question, no explanation.

Query: {question}

Expanded question:""")


def is_short_or_numeric(question: str) -> bool:
    """
    Returns True if the query is a bare number, or 1-2 words.
    These queries produce unreliable embeddings and need expansion first.
    Examples: "1857", "42", "akbar", "rai"
    """
    q = question.strip()
    if re.fullmatch(r"[\d\s.,/-]+", q):   # pure number(s) / dates
        return True
    if len(q.split()) <= 2:               # 1-2 word queries
        return True
    return False


# ─────────────────────────────────────────────────────────────────────
# SEARCH-BACK REWRITER PROMPT
# Rewrites a query that returned poor retrieval results (post-retrieval).
# ─────────────────────────────────────────────────────────────────────
REWRITER_PROMPT = ChatPromptTemplate.from_template("""\
The following query retrieved poor results from a document search engine about Indian history and research papers.
Rewrite it as a clear, specific question that includes relevant context keywords.
Return ONLY the rewritten question, no explanation.

Original question: {question}
""")


# ─────────────────────────────────────────────────────────────────────
# MULTI-QUERY PROMPT
# When a single query fails the threshold, generate 3 alternative
# phrasings and try all of them — the best-scoring docs across all
# variants are merged and returned.
# ─────────────────────────────────────────────────────────────────────
MULTI_QUERY_PROMPT = ChatPromptTemplate.from_template("""\
Generate 3 different search queries to find information about the following topic.
The search engine contains documents about Indian history and research papers.
Use different keywords and phrasings for each query.
Return ONLY the 3 queries, one per line, no numbering or explanation.

Topic: {question}
""")


# ─────────────────────────────────────────────────────────────────────
# RAG PROMPT — now includes chat history for continuity
# ─────────────────────────────────────────────────────────────────────
RAG_PROMPT = ChatPromptTemplate.from_template("""\
You are test_rag_pipeline, an expert AI research assistant.
Answer questions based strictly on the provided research paper excerpts.

Rules:
1. Use ONLY the information in the Context below.
2. If the answer is not in the context, say: "This information was not found in the provided papers."
3. Always cite your sources: mention the paper filename and page number.
4. Be concise and precise. Avoid padding or repetition.
5. You may refer to the Chat History below for context on earlier parts of the conversation.

─────────────────────────────────────────────
Chat History (for reference only):
{history}
─────────────────────────────────────────────
Context (retrieved from your research papers):
{context}
─────────────────────────────────────────────

Question: {question}

Answer (with citations):
""")


# ─────────────────────────────────────────────────────────────────────
# HELPERS
# ─────────────────────────────────────────────────────────────────────
def format_docs(docs: list) -> str:
    """Formats retrieved Document chunks into a single string for the prompt."""
    if not docs:
        return "No relevant documents were found."
    formatted = []
    for i, doc in enumerate(docs, 1):
        filename = doc.metadata.get("filename", "unknown.pdf")
        page     = doc.metadata.get("page", "?")
        if isinstance(page, int):
            page = page + 1   # PyPDFLoader is 0-indexed; PDFs are 1-indexed
        content  = doc.page_content.strip()
        formatted.append(f"[Chunk {i} | File: {filename} | Page: {page}]\n{content}")
    return "\n\n" + "\n\n".join(formatted) + "\n"


def format_history(history: list[dict]) -> str:
    """
    Converts a list of {"role": ..., "content": ...} dicts into
    a readable string for injection into prompts.

    Example output:
        User: Who was Akbar?
        Assistant: Akbar was the third Mughal emperor...
    """
    if not history:
        return "No previous conversation."
    lines = []
    for msg in history:
        role = "User" if msg["role"] == "user" else "Assistant"
        lines.append(f"{role}: {msg['content']}")
    return "\n".join(lines)


# ─────────────────────────────────────────────────────────────────────
# SEARCH-BACK: retry with rewritten query if results are poor
# ─────────────────────────────────────────────────────────────────────
NO_RELEVANT_DOCS_RESPONSE = "I couldn't find relevant information in the provided documents to answer this question."


def make_retrieve_with_fallback(vectorstore, llm):
    rewriter      = REWRITER_PROMPT   | llm | StrOutputParser()
    multi_querier = MULTI_QUERY_PROMPT | llm | StrOutputParser()

    def retrieve_with_fallback(inputs: dict) -> dict:
        question = inputs["question"]
        history  = inputs.get("history", [])

        # ── Attempt 1: direct retrieval ───────────────────────────────
        docs, below_threshold = retrieve_with_scores(vectorstore, question)
        if not below_threshold:
            return {"context": format_docs(docs), "question": question, "history": format_history(history)}

        # ── Attempt 2: single rewrite ─────────────────────────────────
        print(f"[search-back] attempt 1 failed, rewriting query...")
        rewritten = rewriter.invoke({"question": question}).strip()
        print(f"[search-back] rewritten: {rewritten!r}")
        docs, below_threshold = retrieve_with_scores(vectorstore, rewritten)
        if not below_threshold:
            return {"context": format_docs(docs), "question": rewritten, "history": format_history(history)}

        # ── Attempt 3: multi-query — try 3 alternative phrasings ─────
        # Merges docs from all variants; keeps unique chunks by content.
        print(f"[search-back] attempt 2 failed, trying multi-query...")
        raw = multi_querier.invoke({"question": question}).strip()
        variants = [q.strip() for q in raw.splitlines() if q.strip()][:3]
        print(f"[search-back] variants: {variants}")

        seen    = set()
        merged  = []
        for variant in variants:
            v_docs, v_below = retrieve_with_scores(vectorstore, variant)
            if not v_below:
                for doc in v_docs:
                    key = doc.page_content[:100]
                    if key not in seen:
                        seen.add(key)
                        merged.append(doc)

        if merged:
            print(f"[search-back] multi-query found {len(merged)} chunks")
            return {"context": format_docs(merged), "question": question, "history": format_history(history)}

        # ── All attempts failed → skip LLM entirely ───────────────────
        print(f"[search-back] all attempts failed — no relevant docs")
        return {"context": "__NO_RELEVANT_DOCS__", "question": question, "history": format_history(history)}

    return RunnableLambda(retrieve_with_fallback)


# ─────────────────────────────────────────────────────────────────────
# SHORT-CIRCUIT: skip LLM entirely if no relevant docs were found
# ─────────────────────────────────────────────────────────────────────
def make_relevance_gate():
    """
    Sits between retrieval and the RAG prompt.
    If retrieval found nothing above the threshold, returns the
    'not found' message directly without calling the LLM.
    """
    def gate(inputs: dict):
        if inputs.get("context") == "__NO_RELEVANT_DOCS__":
            raise _NoRelevantDocsError()
        return inputs
    return RunnableLambda(gate)


class _NoRelevantDocsError(Exception):
    pass


# ─────────────────────────────────────────────────────────────────────
# CONTEXTUALIZE: rewrite follow-up question using history
# ─────────────────────────────────────────────────────────────────────
def make_contextualize_fn(llm):
    contextualize_chain = CONTEXTUALIZE_PROMPT | llm | StrOutputParser()
    expander_chain      = EXPANDER_PROMPT      | llm | StrOutputParser()

    def contextualize(inputs: dict) -> dict:
        question = inputs["question"]
        history  = inputs.get("history", [])

        # ── Step 1: expand bare numbers / very short queries ──────────
        # Must run BEFORE retrieval — "1857" has no useful embedding.
        if is_short_or_numeric(question):
            expanded = expander_chain.invoke({"question": question}).strip()
            print(f"[expand] {question!r} → {expanded!r}")
            question = expanded

        # ── Step 2: rewrite follow-up questions using history ─────────
        if history:
            standalone = contextualize_chain.invoke({
                "history":  format_history(history),
                "question": question,
            }).strip()
            print(f"[contextualize] {question!r} → {standalone!r}")
            question = standalone

        return {**inputs, "question": question}

    return RunnableLambda(contextualize)


# ─────────────────────────────────────────────────────────────────────
# BUILD THE HISTORY-AWARE RAG CHAIN
# Input:  {"question": str, "history": list[dict]}
# Output: answer string
# ─────────────────────────────────────────────────────────────────────
def _build_chain(llm, vectorstore):
    """
    Shared internal builder used by both batch and streaming chains.

    Flow:
      contextualize → retrieve+threshold → [gate] → RAG_PROMPT → llm → str

    If no chunks pass the relevance threshold, the gate raises
    _NoRelevantDocsError which is caught here to return the
    'not found' message without calling the LLM at all.
    """
    contextualize = make_contextualize_fn(llm)
    retrieve      = make_retrieve_with_fallback(vectorstore, llm)
    gate          = make_relevance_gate()
    rag           = RAG_PROMPT | llm | StrOutputParser()

    def run(inputs: dict) -> str:
        try:
            step1 = contextualize.invoke(inputs)
            step2 = retrieve.invoke(step1)
            step3 = gate.invoke(step2)
            return rag.invoke(step3)
        except _NoRelevantDocsError:
            return NO_RELEVANT_DOCS_RESPONSE

    return RunnableLambda(run)


def _make_llm():
    return ChatOllama(
        model       = OLLAMA_MODEL,
        base_url    = OLLAMA_BASE_URL,
        temperature = OLLAMA_TEMPERATURE,
    )


def build_rag_chain():
    _, vectorstore = load_retriever()
    return _build_chain(_make_llm(), vectorstore)


def build_streaming_chain():
    """
    Streams tokens for matching queries.
    Falls back to a plain string for no-match responses.
    Usage:
        chain = build_streaming_chain()
        for chunk in chain.stream({"question": "Who was Akbar?", "history": []}):
            print(chunk, end="", flush=True)
    """
    _, vectorstore = load_retriever()
    return _build_chain(_make_llm(), vectorstore)


def build_chain_from_vectorstore(vectorstore):
    """Build a fresh chain (new LLM instance) from an already-loaded vectorstore."""
    return _build_chain(_make_llm(), vectorstore)


# ─────────────────────────────────────────────────────────────────────
# TEST RUN
# ─────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    print("=" * 55)
    print("  test_rag_pipeline — History-Aware RAG Chain Test")
    print(f"  LLM    : {OLLAMA_MODEL} (local Ollama)")
    print(f"  Mode   : Streaming")
    print("=" * 55)

    chain = build_streaming_chain()

    # Simulated multi-turn conversation
    history = []
    questions = [
        "Who was Akbar?",
        "How many wives did he have?",       # follow-up — "he" = Akbar
        "What empire did he rule?",           # follow-up — "he" = Akbar
    ]

    for q in questions:
        print(f"\nUser: {q}")
        print("Assistant: ", end="")
        answer = ""
        for token in chain.stream({"question": q, "history": history}):
            print(token, end="", flush=True)
            answer += token
        print("\n" + "─" * 55)

        # Append to history after each turn
        history.append({"role": "user",      "content": q})
        history.append({"role": "assistant", "content": answer})