# evaluation/ab_test.py
# ─────────────────────────────────────────────────────────────────────
# PURPOSE: A/B comparison harness — rag_chain vs rag_graph.
#
# Compares the two RAG implementations on the same test questions:
#   A — rag_chain.py  : LCEL chain with 3-stage fallback (search-back + multi-query)
#   B — rag_graph.py  : LangGraph corrective RAG (grade → rewrite loop)
#
# Metrics collected per question:
#   - response_time (seconds)
#   - answer_length (characters)
#   - found         (True if answer contains content, not "not found")
#   - answer        (first 120 chars for manual inspection)
#
# Run: python evaluation/ab_test.py
# ─────────────────────────────────────────────────────────────────────

import os
import sys
import time

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from retriever import load_retriever
from rag_chain import build_chain_from_vectorstore
from rag_graph import build_rag_graph, initial_state

NOT_FOUND_PHRASES = [
    "not found",
    "no relevant",
    "couldn't find",
    "not in the",
    "no information",
]

TEST_QUESTIONS = [
    "Who was Akbar and what empire did he rule?",
    "What was the Battle of Panipat?",
    "Who was Ashoka?",
    "What is the significance of the Taj Mahal?",
    "Tell me about the Mughal empire.",
    "Who was Shivaji?",
    "What happened during the Indian independence movement?",
    "What is attention mechanism in transformer models?",  # out-of-domain — tests fallback
]


def _found(answer: str) -> bool:
    low = answer.lower()
    return not any(p in low for p in NOT_FOUND_PHRASES)


def run_chain_a(chain, questions: list[str]) -> list[dict]:
    results = []
    for q in questions:
        t0 = time.time()
        try:
            answer = chain.invoke({"question": q, "history": []})
        except Exception as e:
            answer = f"[ERROR] {e}"
        elapsed = time.time() - t0
        results.append({
            "question": q,
            "response_time": round(elapsed, 2),
            "answer_length": len(answer),
            "found": _found(answer),
            "answer_preview": answer[:120].replace("\n", " "),
        })
    return results


def run_chain_b(graph, questions: list[str]) -> list[dict]:
    results = []
    for q in questions:
        t0 = time.time()
        try:
            state = graph.invoke(initial_state(q))
            answer = state.get("answer", "")
        except Exception as e:
            answer = f"[ERROR] {e}"
        elapsed = time.time() - t0
        results.append({
            "question": q,
            "response_time": round(elapsed, 2),
            "answer_length": len(answer),
            "found": _found(answer),
            "answer_preview": answer[:120].replace("\n", " "),
        })
    return results


def print_comparison(results_a: list[dict], results_b: list[dict]) -> None:
    print("\n" + "=" * 90)
    print(f"  {'A/B TEST':^86}")
    print(f"  {'A: rag_chain (LCEL + search-back)':<43} {'B: rag_graph (LangGraph corrective)':<43}")
    print("=" * 90)

    total_time_a = total_time_b = 0.0
    found_a = found_b = 0

    for a, b in zip(results_a, results_b):
        q = a["question"][:46] + ".." if len(a["question"]) > 48 else a["question"]
        found_mark_a = "✓" if a["found"] else "✗"
        found_mark_b = "✓" if b["found"] else "✗"

        print(f"\n  Q: {q}")
        print(
            f"  A: {a['response_time']:.1f}s | {a['answer_length']:>5} chars | found:{found_mark_a}"
            f"  |  B: {b['response_time']:.1f}s | {b['answer_length']:>5} chars | found:{found_mark_b}"
        )
        print(f"    A answer: {a['answer_preview'][:80]}")
        print(f"    B answer: {b['answer_preview'][:80]}")

        total_time_a += a["response_time"]
        total_time_b += b["response_time"]
        found_a += int(a["found"])
        found_b += int(b["found"])

    n = len(results_a)
    print("\n" + "-" * 90)
    print(f"  SUMMARY ({n} questions)")
    print(f"  A — avg time: {total_time_a/n:.1f}s  |  found: {found_a}/{n}")
    print(f"  B — avg time: {total_time_b/n:.1f}s  |  found: {found_b}/{n}")
    winner_time  = "A" if total_time_a < total_time_b else "B"
    winner_found = "A" if found_a > found_b else ("B" if found_b > found_a else "TIE")
    print(f"  Faster:       {winner_time}")
    print(f"  More answers: {winner_found}")
    print("=" * 90)


def run_ab_test():
    print("=" * 60)
    print("  ResearchMind — A/B Test")
    print("  A: rag_chain.py  (LCEL + search-back + multi-query)")
    print("  B: rag_graph.py  (LangGraph corrective RAG)")
    print("=" * 60)

    print("\nLoading vectorstore...")
    _, vectorstore = load_retriever()

    print("Building chain A (rag_chain)...")
    chain_a = build_chain_from_vectorstore(vectorstore)

    print("Building chain B (rag_graph)...")
    graph_b = build_rag_graph()

    print(f"\nRunning {len(TEST_QUESTIONS)} questions on A...")
    results_a = run_chain_a(chain_a, TEST_QUESTIONS)

    print(f"Running {len(TEST_QUESTIONS)} questions on B...")
    results_b = run_chain_b(graph_b, TEST_QUESTIONS)

    print_comparison(results_a, results_b)


if __name__ == "__main__":
    run_ab_test()
