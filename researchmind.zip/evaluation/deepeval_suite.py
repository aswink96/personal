# evaluation/deepeval_suite.py
# ─────────────────────────────────────────────────────────────────────
# PURPOSE: DeepEval test suite for the RAG pipeline.
#
# Metrics evaluated:
#   - AnswerRelevancy   : is the answer on-topic for the question?
#   - Faithfulness      : is the answer grounded in the retrieved context?
#   - ContextualPrecision: are retrieved chunks relevant to the question?
#   - ContextualRecall  : does the context cover what the answer needs?
#
# Judge LLM: local Ollama (same model as the RAG pipeline).
# No OpenAI API keys required.
#
# Run: python evaluation/deepeval_suite.py
# ─────────────────────────────────────────────────────────────────────

import os
import sys
import time

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from langchain_ollama import ChatOllama
from langchain_core.messages import HumanMessage
from deepeval.models.base_model import DeepEvalBaseLLM
from deepeval.metrics import (
    AnswerRelevancyMetric,
    FaithfulnessMetric,
    ContextualPrecisionMetric,
    ContextualRecallMetric,
)
from deepeval.test_case import LLMTestCase

from config.settings import OLLAMA_MODEL, OLLAMA_BASE_URL, OLLAMA_TEMPERATURE


# ─────────────────────────────────────────────────────────────────────
# LOCAL OLLAMA JUDGE
# ─────────────────────────────────────────────────────────────────────
class OllamaJudge(DeepEvalBaseLLM):
    """Wraps local Ollama as the DeepEval judge LLM — no API keys needed."""

    def __init__(self, model: str = OLLAMA_MODEL, base_url: str = OLLAMA_BASE_URL):
        self._model_name = model
        self._base_url = base_url
        self._llm = None
        # DeepEvalBaseLLM.__init__ calls load_model() — skip it via object.__init__
        object.__init__(self)

    def load_model(self):
        if self._llm is None:
            self._llm = ChatOllama(
                model=self._model_name,
                base_url=self._base_url,
                temperature=0,
            )
        return self._llm

    def generate(self, prompt: str, *args, **kwargs) -> str:
        llm = self.load_model()
        response = llm.invoke([HumanMessage(content=prompt)])
        return response.content

    async def a_generate(self, prompt: str, *args, **kwargs) -> str:
        return self.generate(prompt)

    def get_model_name(self, *args, **kwargs) -> str:
        return self._model_name


# ─────────────────────────────────────────────────────────────────────
# TEST CASES
# Questions about Indian history — the indexed PDF content domain.
# ─────────────────────────────────────────────────────────────────────
TEST_QUESTIONS = [
    {
        "input": "Who was Akbar and what is he known for?",
        "expected_output": "Akbar was the third Mughal emperor, known for his religious tolerance, military conquests, and administrative reforms.",
    },
    {
        "input": "What was the significance of the Battle of Panipat?",
        "expected_output": "The Battle of Panipat marked the beginning of the Mughal Empire and the end of the Lodi Sultanate in 1526.",
    },
    {
        "input": "Who was Ashoka and what religion did he adopt?",
        "expected_output": "Ashoka was a Maurya emperor who converted to Buddhism after the Kalinga War and spread Buddhist teachings.",
    },
]


# ─────────────────────────────────────────────────────────────────────
# RUNNER
# ─────────────────────────────────────────────────────────────────────
def build_test_cases(chain, vectorstore) -> list[LLMTestCase]:
    """
    Run each test question through the RAG chain and collect:
      - actual_output    : the chain's answer
      - retrieval_context: the text of the retrieved chunks
    """
    from retriever import retrieve_with_scores

    test_cases = []
    for item in TEST_QUESTIONS:
        question = item["input"]
        expected = item.get("expected_output", "")

        print(f"\n  Running: {question!r}")
        t0 = time.time()

        actual_output = chain.invoke({"question": question, "history": []})

        docs, _ = retrieve_with_scores(vectorstore, question)
        retrieval_context = [doc.page_content for doc in docs]

        elapsed = time.time() - t0
        print(f"  Done in {elapsed:.1f}s  ({len(retrieval_context)} chunks retrieved)")

        test_cases.append(
            LLMTestCase(
                input=question,
                actual_output=actual_output,
                expected_output=expected,
                retrieval_context=retrieval_context,
            )
        )

    return test_cases


def run_deepeval_suite():
    from retriever import load_retriever
    from rag_chain import build_chain_from_vectorstore

    print("=" * 60)
    print("  ResearchMind — DeepEval Evaluation Suite")
    print(f"  Judge LLM : {OLLAMA_MODEL} (local Ollama)")
    print("=" * 60)

    _, vectorstore = load_retriever()
    chain = build_chain_from_vectorstore(vectorstore)
    judge = OllamaJudge()

    metrics = [
        AnswerRelevancyMetric(threshold=0.5, model=judge, include_reason=True),
        FaithfulnessMetric(threshold=0.5, model=judge, include_reason=True),
        ContextualPrecisionMetric(threshold=0.5, model=judge, include_reason=True),
        ContextualRecallMetric(threshold=0.5, model=judge, include_reason=True),
    ]

    print("\n[1/2] Generating answers and retrieving context...")
    test_cases = build_test_cases(chain, vectorstore)

    print("\n[2/2] Scoring with DeepEval metrics...")
    results = []
    for tc in test_cases:
        row = {"question": tc.input}
        for metric in metrics:
            try:
                metric.measure(tc)
                row[metric.__class__.__name__] = round(metric.score, 3)
            except Exception as e:
                row[metric.__class__.__name__] = f"ERR: {e}"
        results.append(row)

    # ── Print summary table ───────────────────────────────────────────
    print("\n" + "=" * 60)
    print("  RESULTS")
    print("=" * 60)
    col_w = 26
    metric_names = [m.__class__.__name__ for m in metrics]
    header = f"{'Question':<30}" + "".join(f"{n[:col_w]:<{col_w}}" for n in metric_names)
    print(header)
    print("-" * len(header))
    for row in results:
        q = row["question"][:28] + ".." if len(row["question"]) > 30 else row["question"]
        scores = "".join(f"{str(row.get(n, '-')):<{col_w}}" for n in metric_names)
        print(f"{q:<30}{scores}")

    return results


if __name__ == "__main__":
    run_deepeval_suite()
