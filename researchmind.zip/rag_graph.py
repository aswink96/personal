# rag_graph.py
# ─────────────────────────────────────────────────────────────────────
# PURPOSE: Corrective RAG pipeline built with LangGraph.
#
# Graph flow:
#   START
#     → retrieve         (FAISS MMR search)
#     → grade_documents  (LLM scores each chunk: relevant or not)
#     → [conditional]
#         if relevant docs found  → generate → END
#         if no relevant docs     → rewrite_query → retrieve  (loop, max 2x)
#         if retries exhausted    → generate anyway → END
#
# Why LangGraph over plain LCEL:
#   - Documents are graded before generation — filters noise
#   - Bad queries auto-rewrite and re-retrieve before giving up
#   - State flows explicitly through named nodes — easy to debug
#
# Run directly to test:  python rag_graph.py
# Used by:               api/main.py
# ─────────────────────────────────────────────────────────────────────

import os
import sys
from typing import TypedDict, List, Literal

from langchain_ollama import ChatOllama
from langchain_core.documents import Document
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langgraph.graph import StateGraph, END, START

sys.path.insert(0, os.path.dirname(__file__))
from retriever import load_retriever
from config.settings import OLLAMA_MODEL, OLLAMA_BASE_URL, OLLAMA_TEMPERATURE


# ─────────────────────────────────────────────────────────────────────
# STATE
# ─────────────────────────────────────────────────────────────────────
class RAGState(TypedDict):
    question:  str
    history:   List[dict]   # list of {"role": "user"|"assistant", "content": str}
    documents: List[Document]
    answer:    str
    retries:   int


# ─────────────────────────────────────────────────────────────────────
# PROMPTS
# ─────────────────────────────────────────────────────────────────────
CONTEXTUALIZE_PROMPT = ChatPromptTemplate.from_template("""\
You are a helpful assistant. Given the chat history below and a follow-up question,
rewrite the follow-up question as a fully self-contained, standalone question.
If the question is already standalone, return it unchanged.
Return ONLY the rewritten question, no explanation.

Chat History:
{history}

Follow-up question: {question}

Standalone question:""")

GRADER_PROMPT = ChatPromptTemplate.from_template("""\
You are a relevance grader for a research paper search engine.
Given a document chunk and a question, decide if the chunk is useful for answering the question.

Respond with ONLY "yes" or "no". No explanation.

Document:
{document}

Question: {question}
""")

REWRITER_PROMPT = ChatPromptTemplate.from_template("""\
You are a query rewriter for a research paper search engine.
The original query retrieved no relevant results. Rewrite it to be more specific and searchable.

Return ONLY the rewritten question. No explanation.

Original question: {question}
""")

RAG_PROMPT = ChatPromptTemplate.from_template("""\
You are test_rag_pipeline, an expert AI research assistant.
Answer the question based strictly on the provided research paper excerpts.

Rules:
1. Use ONLY the information in the Context below.
2. If the answer is not in the context, say: "This information was not found in the provided papers."
3. Always cite your sources: mention the paper filename and page number.
4. Be concise and precise. Avoid padding or repetition.
5. You may refer to the Chat History below for context on earlier parts of the conversation.

─────────────────────────────────────────────
Chat History (for reference only):
{history}
─────────────────────────────────────────────
Context (retrieved from your research papers):
{context}
─────────────────────────────────────────────

Question: {question}

Answer (with citations):
""")


# ─────────────────────────────────────────────────────────────────────
# HELPERS
# ─────────────────────────────────────────────────────────────────────
def _format_history(history: List[dict]) -> str:
    if not history:
        return "No previous conversation."
    lines = []
    for msg in history:
        role = "User" if msg["role"] == "user" else "Assistant"
        lines.append(f"{role}: {msg['content']}")
    return "\n".join(lines)


def _format_docs(docs: List[Document]) -> str:
    if not docs:
        return "No relevant documents were found."
    parts = []
    for i, doc in enumerate(docs, 1):
        filename = doc.metadata.get("filename", "unknown.pdf")
        page = doc.metadata.get("page", "?")
        if isinstance(page, int):
            page = page + 1
        parts.append(f"[Chunk {i} | File: {filename} | Page: {page}]\n{doc.page_content.strip()}")
    return "\n\n".join(parts)


def _llm() -> ChatOllama:
    return ChatOllama(
        model=OLLAMA_MODEL,
        base_url=OLLAMA_BASE_URL,
        temperature=OLLAMA_TEMPERATURE,
    )


# ─────────────────────────────────────────────────────────────────────
# NODES
# ─────────────────────────────────────────────────────────────────────
def make_contextualize_node(llm):
    contextualize_chain = CONTEXTUALIZE_PROMPT | llm | StrOutputParser()

    def contextualize(state: RAGState) -> dict:
        history = state.get("history", [])
        if not history:
            return {}
        standalone = contextualize_chain.invoke({
            "history":  _format_history(history),
            "question": state["question"],
        }).strip()
        print(f"[contextualize] {state['question']!r} → {standalone!r}")
        return {"question": standalone}

    return contextualize


def make_retrieve_node(retriever):
    def retrieve(state: RAGState) -> dict:
        print(f"[retrieve] query: {state['question']!r}")
        docs = retriever.invoke(state["question"])
        print(f"[retrieve] fetched {len(docs)} chunks")
        return {"documents": docs}
    return retrieve


def make_grade_node(llm):
    grader_chain = GRADER_PROMPT | llm | StrOutputParser()

    def grade_documents(state: RAGState) -> dict:
        relevant = []
        for doc in state["documents"]:
            score = grader_chain.invoke({
                "document": doc.page_content[:600],
                "question": state["question"],
            }).strip().lower()
            if score.startswith("yes"):
                relevant.append(doc)
        print(f"[grade] {len(relevant)}/{len(state['documents'])} chunks relevant")
        return {"documents": relevant}

    return grade_documents


def make_rewrite_node(llm):
    rewriter_chain = REWRITER_PROMPT | llm | StrOutputParser()

    def rewrite_query(state: RAGState) -> dict:
        new_question = rewriter_chain.invoke({"question": state["question"]}).strip()
        retries = state.get("retries", 0) + 1
        print(f"[rewrite] attempt {retries}: {new_question!r}")
        return {"question": new_question, "retries": retries}

    return rewrite_query


def make_generate_node(llm):
    generate_chain = RAG_PROMPT | llm | StrOutputParser()

    def generate(state: RAGState) -> dict:
        answer = generate_chain.invoke({
            "context":  _format_docs(state["documents"]),
            "question": state["question"],
            "history":  _format_history(state.get("history", [])),
        })
        return {"answer": answer}

    return generate


# ─────────────────────────────────────────────────────────────────────
# CONDITIONAL EDGE
# ─────────────────────────────────────────────────────────────────────
MAX_RETRIES = 2

def decide_after_grading(state: RAGState) -> Literal["generate", "rewrite_query"]:
    if state["documents"]:
        return "generate"
    if state.get("retries", 0) >= MAX_RETRIES:
        print("[decide] no relevant docs after max retries — generating anyway")
        return "generate"
    return "rewrite_query"


# ─────────────────────────────────────────────────────────────────────
# GRAPH BUILDER
# ─────────────────────────────────────────────────────────────────────
def build_rag_graph():
    """
    Compiles and returns the Corrective RAG graph.

    Usage (batch):
        graph = build_rag_graph()
        result = graph.invoke({"question": "What is RAG?", "documents": [], "answer": "", "retries": 0})
        print(result["answer"])

    Usage (token streaming):
        async for event in graph.astream_events({...}, version="v2"):
            if event["event"] == "on_chat_model_stream":
                if event.get("metadata", {}).get("langgraph_node") == "generate":
                    print(event["data"]["chunk"].content, end="", flush=True)
    """
    retriever, _ = load_retriever()
    llm = _llm()

    workflow = StateGraph(RAGState)

    workflow.add_node("contextualize",   make_contextualize_node(llm))
    workflow.add_node("retrieve",        make_retrieve_node(retriever))
    workflow.add_node("grade_documents", make_grade_node(llm))
    workflow.add_node("rewrite_query",   make_rewrite_node(llm))
    workflow.add_node("generate",        make_generate_node(llm))

    workflow.add_edge(START, "contextualize")
    workflow.add_edge("contextualize", "retrieve")
    workflow.add_edge("retrieve", "grade_documents")
    workflow.add_conditional_edges(
        "grade_documents",
        decide_after_grading,
        {"generate": "generate", "rewrite_query": "rewrite_query"},
    )
    workflow.add_edge("rewrite_query", "retrieve")
    workflow.add_edge("generate", END)

    return workflow.compile()


def initial_state(question: str, history: list = None) -> RAGState:
    """Returns a starting state for the graph."""
    return {"question": question, "history": history or [], "documents": [], "answer": "", "retries": 0}


# ─────────────────────────────────────────────────────────────────────
# TEST RUN
# ─────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    print("=" * 55)
    print("  test_rag_pipeline — LangGraph Corrective RAG Test")
    print(f"  LLM: {OLLAMA_MODEL}")
    print("=" * 55)

    graph = build_rag_graph()

    # Simulated multi-turn conversation
    history = []
    questions = [
        "What is the attention mechanism and why was it introduced?",
        "How does it compare to RNNs?",   # follow-up — "it" = attention mechanism
    ]

    for q in questions:
        print(f"\nUser: {q}")
        result = graph.invoke(initial_state(q, history))
        print(f"Assistant: {result['answer']}")
        print("-" * 55)

        # Append to history after each turn
        history.append({"role": "user",      "content": q})
        history.append({"role": "assistant", "content": result["answer"]})
