# scripts/download_250_papers.py
# ─────────────────────────────────────────────────────────────────────
# PURPOSE: Automatically downloads 250 research papers from ArXiv
#          across 10 mixed AI/ML topics (25 papers per topic).
#
# Topics covered:
#   1. Large Language Models        (25 papers)
#   2. Retrieval Augmented Generation (25 papers)
#   3. Agent & Reasoning            (25 papers)
#   4. Computer Vision              (25 papers)
#   5. Reinforcement Learning       (25 papers)
#   6. NLP & Text Classification    (25 papers)
#   7. Diffusion & Generative AI    (25 papers)
#   8. Transformers & Attention     (25 papers)
#   9. Fine-tuning & PEFT           (25 papers)
#  10. AI Safety & Alignment        (25 papers)
#
# Run:  python scripts/download_250_papers.py
# ─────────────────────────────────────────────────────────────────────

import arxiv
import os
import time

# ── Output folder ─────────────────────────────────────────────────────
OUTPUT_DIR    = "data/papers"
PAPERS_PER_TOPIC = 25        # 10 topics × 25 = 250 papers
os.makedirs(OUTPUT_DIR, exist_ok=True)

# ── Topics and their ArXiv search queries ─────────────────────────────
# Each query is tuned to return high-quality, relevant papers
TOPICS = {
    "llm": {
        "label"  : "Large Language Models",
        "query"  : "large language models GPT LLM benchmark evaluation",
    },
    "rag": {
        "label"  : "Retrieval Augmented Generation",
        "query"  : "retrieval augmented generation RAG knowledge grounding",
    },
    "agents": {
        "label"  : "Agents & Reasoning",
        "query"  : "LLM agents autonomous reasoning tool use planning",
    },
    "vision": {
        "label"  : "Computer Vision",
        "query"  : "vision transformer image classification object detection deep learning",
    },
    "rl": {
        "label"  : "Reinforcement Learning",
        "query"  : "reinforcement learning policy optimization reward deep RL",
    },
    "nlp": {
        "label"  : "NLP & Text Classification",
        "query"  : "natural language processing text classification sentiment BERT",
    },
    "diffusion": {
        "label"  : "Diffusion & Generative AI",
        "query"  : "diffusion model generative AI image synthesis stable diffusion",
    },
    "transformers": {
        "label"  : "Transformers & Attention",
        "query"  : "transformer attention mechanism self-attention architecture",
    },
    "finetuning": {
        "label"  : "Fine-tuning & PEFT",
        "query"  : "fine-tuning LoRA PEFT parameter efficient LLM adaptation",
    },
    "safety": {
        "label"  : "AI Safety & Alignment",
        "query"  : "AI safety alignment RLHF constitutional AI harmless helpful",
    },
}


# ─────────────────────────────────────────────────────────────────────
# DOWNLOAD FUNCTION
# ─────────────────────────────────────────────────────────────────────
def download_topic(topic_key: str, topic_info: dict, count: int) -> int:
    """
    Downloads `count` papers for a given topic from ArXiv.

    How ArXiv search works:
      - arxiv.Search() queries ArXiv's API with a text query
      - Results sorted by relevance (most cited/relevant first)
      - Each result has: title, authors, abstract, pdf_url, entry_id
      - result.download_pdf() fetches the actual PDF file

    Returns: number of successfully downloaded papers
    """
    label   = topic_info["label"]
    query   = topic_info["query"]

    print(f"\n📚 [{label}] — downloading {count} papers...")
    print(f"   Query: '{query}'")

    # Search ArXiv
    search = arxiv.Search(
        query          = query,
        max_results    = count + 5,    # fetch a few extra in case some fail
        sort_by        = arxiv.SortCriterion.Relevance,
    )

    downloaded = 0
    client     = arxiv.Client()

    for result in client.results(search):
        if downloaded >= count:
            break

        # Clean filename: topic_key + arxiv_id
        # e.g. "llm_2303.08774v1.pdf"
        arxiv_id = result.entry_id.split("/")[-1]
        filename = f"{topic_key}_{arxiv_id}.pdf"
        filepath = os.path.join(OUTPUT_DIR, filename)

        # Skip if already downloaded
        if os.path.exists(filepath):
            print(f"   ⏭️  Already exists: {filename}")
            downloaded += 1
            continue

        try:
            # Download PDF directly from ArXiv
            result.download_pdf(dirpath=OUTPUT_DIR, filename=filename)
            size_kb = os.path.getsize(filepath) // 1024
            print(f"   ✅ [{downloaded+1}/{count}] {filename} ({size_kb}KB)")
            downloaded += 1
            time.sleep(1)    # polite delay — ArXiv rate limits aggressive downloaders

        except Exception as e:
            print(f"   ❌ Failed: {filename} — {e}")
            time.sleep(2)    # wait longer after a failure

    return downloaded


# ─────────────────────────────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    print("=" * 60)
    print("  test_rag_pipeline — Downloading 250 ArXiv Papers")
    print(f"  Topics  : {len(TOPICS)}")
    print(f"  Per topic: {PAPERS_PER_TOPIC}")
    print(f"  Total   : {len(TOPICS) * PAPERS_PER_TOPIC} papers")
    print(f"  Output  : {OUTPUT_DIR}/")
    print("=" * 60)
    print("⏱️  Estimated time: 10–20 minutes (depends on internet speed)")
    print("💡  Already downloaded papers are skipped automatically")
    print("💡  Safe to re-run if interrupted\n")

    total_downloaded = 0
    failed_topics    = []

    for topic_key, topic_info in TOPICS.items():
        try:
            n = download_topic(topic_key, topic_info, PAPERS_PER_TOPIC)
            total_downloaded += n
        except Exception as e:
            print(f"\n❌ Topic '{topic_key}' failed entirely: {e}")
            failed_topics.append(topic_key)

    # ── Final summary ──────────────────────────────────────────────────
    print("\n" + "=" * 60)
    print(f"✅ Total downloaded : {total_downloaded} papers")
    print(f"📂 Location        : {OUTPUT_DIR}/")

    # Count actual files on disk
    actual = len([f for f in os.listdir(OUTPUT_DIR) if f.endswith(".pdf")])
    print(f"📄 Files on disk   : {actual} PDFs")

    if failed_topics:
        print(f"❌ Failed topics   : {', '.join(failed_topics)}")
        print(f"   Re-run the script to retry failed topics")

    print("\n🚀 Next step: python ingest.py")
    print("   (Re-run ingest to rebuild index with all 250 papers)")
    print("=" * 60)
