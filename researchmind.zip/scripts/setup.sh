#!/bin/bash
# scripts/setup.sh
# ─────────────────────────────────────────────────────────────────────
# PURPOSE: One-shot setup script for Ubuntu + NVIDIA GPU.
#          Installs all dependencies, sets up Ollama, pulls the model.
#          Run once after cloning the project.
#
# Usage:   bash scripts/setup.sh
# ─────────────────────────────────────────────────────────────────────

set -e   # exit on any error

echo "=================================================="
echo "  ResearchMind — Setup (Ubuntu + NVIDIA GPU)"
echo "=================================================="

# ── 1. Python virtual environment ─────────────────────────────────────
echo ""
echo "📦 Step 1: Creating virtual environment..."
python3 -m venv venv
source venv/bin/activate
pip install --upgrade pip --quiet

# ── 2. Install PyTorch with CUDA support ──────────────────────────────
# Must install BEFORE sentence-transformers so GPU is detected
echo ""
echo "🔥 Step 2: Installing PyTorch with CUDA support..."
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu121 --quiet
echo "   ✅ PyTorch installed with CUDA 12.1"

# ── 3. Install project dependencies ───────────────────────────────────
echo ""
echo "📚 Step 3: Installing project dependencies..."
pip install -r requirements.txt --quiet
echo "   ✅ All packages installed"

# ── 4. Install Ollama ─────────────────────────────────────────────────
echo ""
echo "🦙 Step 4: Installing Ollama..."
if command -v ollama &> /dev/null; then
    echo "   ✅ Ollama already installed: $(ollama --version)"
else
    curl -fsSL https://ollama.com/install.sh | sh
    echo "   ✅ Ollama installed"
fi

# ── 5. Start Ollama service ───────────────────────────────────────────
echo ""
echo "🚀 Step 5: Starting Ollama service..."
ollama serve &>/dev/null &
sleep 3
echo "   ✅ Ollama running at http://localhost:11434"

# ── 6. Pull Mistral model ─────────────────────────────────────────────
# Mistral 7B: best quality for 32GB RAM + NVIDIA GPU
echo ""
echo "⬇️  Step 6: Pulling Mistral model (~4GB, runs on GPU)..."
echo "   This downloads once and is cached locally."
ollama pull mistral
echo "   ✅ Mistral ready"

# ── 7. Create project folders ─────────────────────────────────────────
echo ""
echo "📁 Step 7: Creating project folders..."
mkdir -p data/papers faiss_index notebooks
echo "   ✅ Folders ready"

# ── 8. Verify GPU is visible ──────────────────────────────────────────
echo ""
echo "🖥️  Step 8: Verifying GPU detection..."
python3 -c "
import torch
if torch.cuda.is_available():
    print(f'   ✅ GPU detected: {torch.cuda.get_device_name(0)}')
    print(f'   VRAM: {torch.cuda.get_device_properties(0).total_memory // 1024**3}GB')
else:
    print('   ⚠️  No GPU detected — will run on CPU (slower)')
"

# ── Done ──────────────────────────────────────────────────────────────
echo ""
echo "=================================================="
echo "  ✅ Setup complete!"
echo ""
echo "  Next steps:"
echo "  1. source venv/bin/activate"
echo "  2. python scripts/download_papers.py   # get sample PDFs"
echo "  3. python ingest.py                    # build FAISS index"
echo "  4. python rag_chain.py                 # test the pipeline"
echo "=================================================="
