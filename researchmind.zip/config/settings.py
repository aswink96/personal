# config/settings.py
# ─────────────────────────────────────────────────────────────────────
# PURPOSE: Central config for the entire test_rag_pipeline pipeline.
#          Change values here — they propagate everywhere.
#          No API keys needed — fully local setup.
# ─────────────────────────────────────────────────────────────────────

import os

# ── Paths ─────────────────────────────────────────────────────────────
PDF_DIR          = "india_wiki_pdfs"    # drop your PDFs here
CHROMA_PATH      = "chroma_index"       # ChromaDB persistent storage directory
CHROMA_COLLECTION = "rag_documents"     # collection name inside ChromaDB

# ── Chunking ──────────────────────────────────────────────────────────
CHUNK_SIZE    = 500             # tokens per chunk (sweet spot for research papers)
CHUNK_OVERLAP = 100             # overlap prevents cutting ideas at boundaries

# ── Embedding Model (local, free, CPU+GPU) ────────────────────────────
# BAAI/bge-small-en-v1.5:
#   - Downloads once (~130MB) to ~/.cache/huggingface/
#   - Runs on CPU or CUDA GPU
#   - Strong semantic understanding for academic text
EMBEDDING_MODEL  = "BAAI/bge-large-en-v1.5"
EMBEDDING_DEVICE = "cuda"         # "cuda" for NVIDIA GPU, "cpu" as fallback

# ── Ollama LLM (local, free) ──────────────────────────────────────────
# With 32GB RAM + NVIDIA GPU, mistral gives best quality
# Options: "gemma4", "mistral", "llama3.1", "llama3.2", "phi3"
OLLAMA_MODEL   = "gemma4:e4b"
OLLAMA_BASE_URL = "http://localhost:11434"
OLLAMA_TEMPERATURE = 0          # 0 = deterministic answers, reduces hallucination

# ── Retrieval ─────────────────────────────────────────────────────────
TOP_K      = 8                  # chunks returned per query
FETCH_K    = 40                 # MMR candidate pool before diversity filtering

MAX_HISTORY_TURNS  = 10         # max Q&A pairs kept in prompt to avoid token bloat
RELEVANCE_THRESHOLD = 0.7
# minimum similarity score (0–1) to accept a chunk
                                 # below this → "no relevant information found"
                                 # BGE cosine scores: 0.7+ great, 0.5 ok, <0.4 noise

# ── PostgreSQL (conversation log) ─────────────────────────────────────
POSTGRES_URL = "postgresql://postgres:root@localhost:5432/rag_pipeline"
