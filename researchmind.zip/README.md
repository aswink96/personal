# ResearchMind 🧠
**Autonomous Research Summarization Agent — Fully Local & Free**

Built with LangChain + LangGraph + Ollama + FAISS + DeepEval.
No API keys. No cloud costs. Runs entirely on your machine.

---

## Stack
| Component | Technology | Cost |
|---|---|---|
| LLM | Ollama + Mistral 7B (GPU) | Free |
| Embeddings | BAAI/bge-small-en-v1.5 | Free |
| Vector Store | FAISS (local) | Free |
| Agent Framework | LangChain + LangGraph | Free |
| Evaluation | DeepEval | Free |
| API | FastAPI | Free |

---

## Quick Start

```bash
# 1. Clone and enter
git clone <your-repo>
cd researchmind

# 2. One-shot setup (Ubuntu + NVIDIA GPU)
bash scripts/setup.sh

# 3. Activate environment
source venv/bin/activate

# 4. Download sample research papers
python scripts/download_papers.py

# 5. Build the FAISS index (run once)
python ingest.py

# 6. Test the RAG pipeline
python rag_chain.py
```

---

## Project Structure

```
researchmind/
├── config/
│   └── settings.py          ← central config (models, paths, params)
├── data/
│   └── papers/              ← drop your PDFs here
├── faiss_index/             ← auto-created by ingest.py
├── agent/
│   ├── planner.py           ← LangGraph orchestration
│   ├── tools.py             ← RAG tool + ArXiv tool
│   ├── memory.py            ← short + long term memory
│   └── summarizer.py        ← structured summarization
├── evaluation/
│   ├── deepeval_suite.py    ← faithfulness, relevancy, hallucination
│   └── ab_test.py           ← model comparison harness
├── api/
│   └── main.py              ← FastAPI server
├── scripts/
│   ├── setup.sh             ← one-shot Ubuntu setup
│   └── download_papers.py   ← fetch sample ArXiv papers
├── notebooks/               ← eval results + visualizations
├── ingest.py                ← PDF → chunks → FAISS index
├── retriever.py             ← FAISS loader + MMR retriever
├── rag_chain.py             ← full RAG chain (retriever + LLM)
└── requirements.txt
```

---

## Modules (Learning Path)

| Module | File | Status |
|---|---|---|
| 2 — Document Loading & Chunking | `ingest.py` | ✅ Done |
| 3 — Embeddings & FAISS | `retriever.py` | ✅ Done |
| 4 — RAG Chain | `rag_chain.py` | ✅ Done |
| 5 — Agent Orchestration | `agent/` | 🔄 Next |
| 6 — Memory | `agent/memory.py` | ⏳ |
| 7 — Tool Use | `agent/tools.py` | ⏳ |
| 8 — Evaluation | `evaluation/` | ⏳ |
| 9 — Observability & A/B Testing | `evaluation/ab_test.py` | ⏳ |
| 10 — FastAPI | `api/main.py` | ⏳ |
