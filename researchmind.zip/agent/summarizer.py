# agent/summarizer.py
# ─────────────────────────────────────────────────────────────────────
# PURPOSE: Structured summarization chains.
#
#   summarize(text)        → structured summary (topic, key points, etc.)
#   bullet_summarize(text) → 3-5 bullet points
#
# Used by the agent to condense retrieved documents before answering,
# and as a standalone tool for summarising a full PDF page.
# ─────────────────────────────────────────────────────────────────────

import os
import sys

from langchain_ollama import ChatOllama
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from config.settings import OLLAMA_MODEL, OLLAMA_BASE_URL, OLLAMA_TEMPERATURE


_STRUCTURED_PROMPT = ChatPromptTemplate.from_template("""\
You are a research assistant. Produce a structured summary of the document excerpts below.

Use exactly this format:

**Topic:** <one-line description>
**Key Points:**
- <point 1>
- <point 2>
- <point 3 (add more if needed)>
**Important Names / Events:** <comma-separated, or "None">
**Time Period:** <e.g. "16th century" or "N/A">
**Conclusion:** <1-2 sentence takeaway>

Document excerpts:
{text}
""")

_BULLET_PROMPT = ChatPromptTemplate.from_template("""\
Summarize the following text as 3-5 concise bullet points. Be factual and specific.

Text:
{text}

Summary:""")


def _llm() -> ChatOllama:
    return ChatOllama(
        model=OLLAMA_MODEL,
        base_url=OLLAMA_BASE_URL,
        temperature=OLLAMA_TEMPERATURE,
    )


def summarize(text: str) -> str:
    """Structured summary: topic, key points, names/events, time period, conclusion."""
    return (_STRUCTURED_PROMPT | _llm() | StrOutputParser()).invoke({"text": text})


def bullet_summarize(text: str) -> str:
    """3-5 bullet-point summary."""
    return (_BULLET_PROMPT | _llm() | StrOutputParser()).invoke({"text": text})


if __name__ == "__main__":
    sample = (
        "The Battle of Panipat was fought on 21 April 1526 between the invading forces "
        "of Babur and the Lodi Empire. It took place in North India and marked the beginning "
        "of the Mughal Empire and the end of the Delhi Sultanate. This was one of the earliest "
        "battles involving gunpowder firearms and field artillery in the Indian subcontinent."
    )
    print("=== Structured Summary ===")
    print(summarize(sample))
    print("\n=== Bullet Summary ===")
    print(bullet_summarize(sample))
