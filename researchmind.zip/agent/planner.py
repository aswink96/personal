# agent/planner.py
# ─────────────────────────────────────────────────────────────────────
# PURPOSE: LangGraph ReAct agent that orchestrates tool use.
#
# Graph (via langchain.agents.create_agent):
#   START → agent (LLM decides tool or final answer)
#         ↔ tools (rag_search / arxiv_search execution)
#         → END  (when LLM produces a final answer with no tool call)
#
# The agent:
#   - Uses rag_search for questions about the indexed PDFs (Indian history)
#   - Uses arxiv_search for recent research / academic topics
#   - Cites all sources in the final answer
#
# Usage:
#   agent = build_agent(vectorstore)
#   answer = run_agent(agent, "Who was Akbar?", history=[])
#
# Run directly: python agent/planner.py
# Used by: api/main.py
# ─────────────────────────────────────────────────────────────────────

import os
import sys

from langchain_ollama import ChatOllama
from langchain_core.messages import HumanMessage, AIMessage, SystemMessage
from langchain.agents import create_agent

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from config.settings import OLLAMA_MODEL, OLLAMA_BASE_URL, OLLAMA_TEMPERATURE
from agent.tools import rag_search, arxiv_search, init_tools


SYSTEM_PROMPT = """\
You are ResearchMind, an expert AI research assistant with access to two tools:

1. rag_search   — searches a local index of Indian history Wikipedia documents
2. arxiv_search — searches ArXiv for recent academic research papers

Guidelines:
- Use rag_search for questions about Indian history, culture, rulers, events, or places.
- Use arxiv_search for recent research, machine learning, AI, or any academic topic.
- Use both tools when the question spans both domains.
- Always cite your sources (document name + page, or ArXiv title + URL).
- If neither tool returns useful results, say so clearly.
- Be concise, factual, and precise.
"""


def _make_llm() -> ChatOllama:
    return ChatOllama(
        model=OLLAMA_MODEL,
        base_url=OLLAMA_BASE_URL,
        temperature=OLLAMA_TEMPERATURE,
    )


def build_agent(vectorstore=None):
    """
    Compile and return the ReAct agent graph.

    Pass a pre-loaded vectorstore to avoid reloading embeddings on first tool call.
    """
    if vectorstore is not None:
        init_tools(vectorstore)

    return create_agent(
        model=_make_llm(),
        tools=[rag_search, arxiv_search],
        system_prompt=SYSTEM_PROMPT,
    )


def run_agent(agent, question: str, history: list[dict] = None) -> str:
    """
    Invoke the agent synchronously and return the final answer string.

    Args:
        agent:    compiled agent from build_agent()
        question: the user's question
        history:  list of {"role": "user"|"assistant", "content": str}
    """
    messages: list = [SystemMessage(content=SYSTEM_PROMPT)]

    for msg in (history or []):
        if msg["role"] == "user":
            messages.append(HumanMessage(content=msg["content"]))
        else:
            messages.append(AIMessage(content=msg["content"]))

    messages.append(HumanMessage(content=question))

    result = agent.invoke({"messages": messages})
    return result["messages"][-1].content


if __name__ == "__main__":
    print("=" * 60)
    print("  ResearchMind — Agent Test")
    print(f"  LLM: {OLLAMA_MODEL}")
    print("=" * 60)

    agent = build_agent()

    history: list[dict] = []
    questions = [
        "Who was Akbar and what empire did he rule?",
        "How many wives did he have?",
        "What are the latest papers on retrieval-augmented generation?",
    ]

    for q in questions:
        print(f"\nUser: {q}")
        answer = run_agent(agent, q, history)
        print(f"Agent: {answer}")
        print("-" * 60)
        history.append({"role": "user", "content": q})
        history.append({"role": "assistant", "content": answer})
