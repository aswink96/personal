# agent/memory.py
# ─────────────────────────────────────────────────────────────────────
# PURPOSE: Memory layers for the agent.
#
#   ShortTermMemory  — in-process sliding window of conversation turns
#   LongTermMemory   — PostgreSQL-backed store for extracted facts
#
# ShortTermMemory is used per-request; its contents are passed as
# the `history` list to the agent and RAG chain.
#
# LongTermMemory stores key facts the agent extracts across sessions
# (separate from the message log in api/main.py).
# ─────────────────────────────────────────────────────────────────────

import os
import sys

import psycopg2
import psycopg2.extras

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from config.settings import POSTGRES_URL, MAX_HISTORY_TURNS


class ShortTermMemory:
    """In-memory sliding-window buffer of conversation turns."""

    def __init__(self, max_turns: int = MAX_HISTORY_TURNS):
        self._history: list[dict] = []
        self._max_turns = max_turns

    def add(self, role: str, content: str) -> None:
        self._history.append({"role": role, "content": content})
        max_msgs = self._max_turns * 2
        if len(self._history) > max_msgs:
            self._history = self._history[-max_msgs:]

    def get(self) -> list[dict]:
        return list(self._history)

    def clear(self) -> None:
        self._history = []

    def formatted(self) -> str:
        if not self._history:
            return "No previous conversation."
        lines = []
        for msg in self._history:
            role = "User" if msg["role"] == "user" else "Assistant"
            lines.append(f"{role}: {msg['content']}")
        return "\n".join(lines)


class LongTermMemory:
    """
    PostgreSQL-backed store for facts the agent extracts across sessions.
    Separate from the conversation message log in api/main.py.

    Usage:
        ltm = LongTermMemory()
        ltm.save_fact(session_id, "The Battle of Panipat was in 1526", source="Panipat.pdf")
        facts = ltm.get_facts(session_id)
    """

    def __init__(self):
        self._ensure_table()

    def _conn(self):
        return psycopg2.connect(POSTGRES_URL)

    def _ensure_table(self) -> None:
        try:
            conn = self._conn()
            with conn:
                with conn.cursor() as cur:
                    cur.execute("""
                        CREATE TABLE IF NOT EXISTS agent_facts (
                            id         SERIAL PRIMARY KEY,
                            session_id TEXT NOT NULL,
                            fact       TEXT NOT NULL,
                            source     TEXT,
                            created_at TIMESTAMPTZ DEFAULT NOW()
                        );
                        CREATE INDEX IF NOT EXISTS agent_facts_session_idx
                            ON agent_facts (session_id);
                    """)
            conn.close()
        except Exception as e:
            print(f"[LongTermMemory] table setup failed: {e}")

    def save_fact(self, session_id: str, fact: str, source: str = None) -> None:
        try:
            conn = self._conn()
            with conn:
                with conn.cursor() as cur:
                    cur.execute(
                        "INSERT INTO agent_facts (session_id, fact, source) VALUES (%s, %s, %s)",
                        (session_id, fact, source),
                    )
            conn.close()
        except Exception as e:
            print(f"[LongTermMemory] save_fact error: {e}")

    def get_facts(self, session_id: str) -> list[str]:
        try:
            conn = self._conn()
            with conn.cursor(cursor_factory=psycopg2.extras.DictCursor) as cur:
                cur.execute(
                    "SELECT fact FROM agent_facts WHERE session_id = %s ORDER BY created_at ASC",
                    (session_id,),
                )
                facts = [row["fact"] for row in cur.fetchall()]
            conn.close()
            return facts
        except Exception as e:
            print(f"[LongTermMemory] get_facts error: {e}")
            return []

    def clear_session(self, session_id: str) -> None:
        try:
            conn = self._conn()
            with conn:
                with conn.cursor() as cur:
                    cur.execute("DELETE FROM agent_facts WHERE session_id = %s", (session_id,))
            conn.close()
        except Exception as e:
            print(f"[LongTermMemory] clear_session error: {e}")
