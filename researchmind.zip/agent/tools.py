# agent/tools.py
# ─────────────────────────────────────────────────────────────────────
# PURPOSE: LangChain tools used by the ReAct agent.
#
#   rag_search   — searches the local ChromaDB index of indexed PDFs
#   arxiv_search — fetches relevant papers from ArXiv
#
# The vectorstore is loaded lazily on first call, or pre-loaded by
# calling init_tools(vectorstore) at startup to skip the embedding reload.
# ─────────────────────────────────────────────────────────────────────

import os
import sys

import arxiv as arxiv_lib
from langchain_core.tools import tool

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from config.settings import TOP_K, RELEVANCE_THRESHOLD

_vectorstore = None


def init_tools(vectorstore) -> None:
    """Pre-load the vectorstore so tools skip the expensive embedding reload."""
    global _vectorstore
    _vectorstore = vectorstore


def _get_vectorstore():
    global _vectorstore
    if _vectorstore is None:
        from retriever import load_vectorstore
        _vectorstore = load_vectorstore()
    return _vectorstore


@tool
def rag_search(query: str) -> str:
    """Search the local document index for information. Use this for questions
    about Indian history, culture, events, people, or any topic likely covered
    in the indexed PDF documents."""
    from retriever import retrieve_with_scores

    vs = _get_vectorstore()
    docs, below_threshold = retrieve_with_scores(vs, query, k=TOP_K, threshold=RELEVANCE_THRESHOLD)

    if below_threshold or not docs:
        return "No relevant information found in the local document index for this query."

    parts = []
    for i, doc in enumerate(docs, 1):
        filename = doc.metadata.get("filename", "unknown.pdf")
        page = doc.metadata.get("page", "?")
        if isinstance(page, int):
            page += 1
        parts.append(f"[Source {i} | {filename} | Page {page}]\n{doc.page_content.strip()}")

    return "\n\n".join(parts)


@tool
def arxiv_search(query: str) -> str:
    """Search ArXiv for recent academic research papers. Use this for questions
    about recent research, machine learning, AI, NLP, or any topic requiring
    up-to-date academic sources not covered in the local documents."""
    try:
        client = arxiv_lib.Client()
        search = arxiv_lib.Search(
            query=query,
            max_results=3,
            sort_by=arxiv_lib.SortCriterion.Relevance,
        )
        results = list(client.results(search))

        if not results:
            return "No ArXiv papers found for this query."

        parts = []
        for r in results:
            authors = ", ".join(a.name for a in r.authors[:3])
            if len(r.authors) > 3:
                authors += " et al."
            parts.append(
                f"Title: {r.title}\n"
                f"Authors: {authors}\n"
                f"Published: {r.published.strftime('%Y-%m-%d')}\n"
                f"Abstract: {r.summary[:600].strip()}...\n"
                f"URL: {r.entry_id}"
            )

        return "\n\n---\n\n".join(parts)

    except Exception as e:
        return f"ArXiv search failed: {e}"
