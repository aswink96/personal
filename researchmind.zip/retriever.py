# retriever.py — ChromaFS
# ─────────────────────────────────────────────────────────────────────
# PURPOSE: Virtual filesystem layer over ChromaDB.
#
# Inspired by Mintlify's ChromaFS — instead of FAISS flat search,
# ChromaDB's metadata filtering lets us do filesystem-style operations:
#
#   list_files()              → all indexed PDF filenames
#   list_pages(filename)      → all page numbers in a PDF
#   cat_page(filename, page)  → reassemble full page from chunks
#   chroma_grep(query, file)  → two-stage search (filter → vector)
#   retrieve_with_scores()    → standard RAG retrieval with L2 threshold
#
# Used by: rag_chain.py, api/main.py
# Depends on: chroma_index/ (created by ingest.py)
# ─────────────────────────────────────────────────────────────────────

import os
import sys

from langchain_community.vectorstores import Chroma
from langchain_community.embeddings import HuggingFaceEmbeddings

sys.path.insert(0, os.path.dirname(__file__))
from config.settings import (
    CHROMA_PATH,
    CHROMA_COLLECTION,
    EMBEDDING_MODEL,
    EMBEDDING_DEVICE,
    TOP_K,
    FETCH_K,
    RELEVANCE_THRESHOLD,
)


# ─────────────────────────────────────────────────────────────────────
# LOAD
# ─────────────────────────────────────────────────────────────────────
def load_embeddings() -> HuggingFaceEmbeddings:
    return HuggingFaceEmbeddings(
        model_name    = EMBEDDING_MODEL,
        model_kwargs  = {"device": EMBEDDING_DEVICE},
        encode_kwargs = {"normalize_embeddings": True},
    )


def load_vectorstore() -> Chroma:
    """Loads the persisted ChromaDB collection from disk."""
    if not os.path.exists(CHROMA_PATH):
        raise FileNotFoundError(
            f"ChromaDB index not found at '{CHROMA_PATH}'.\n"
            f"Run: python ingest.py"
        )

    print(f"📦 Loading ChromaDB from '{CHROMA_PATH}' (collection: {CHROMA_COLLECTION})...")
    embeddings  = load_embeddings()
    vectorstore = Chroma(
        persist_directory   = CHROMA_PATH,
        embedding_function  = embeddings,
        collection_name     = CHROMA_COLLECTION,
        collection_metadata = {"hnsw:space": "l2"},
    )
    total = vectorstore._collection.count()
    print(f"✅ ChromaDB ready — {total} chunks indexed")
    return vectorstore


def load_retriever(k: int = TOP_K):
    """Returns (retriever, vectorstore) for backward compatibility with rag_chain.py."""
    vectorstore = load_vectorstore()
    retriever   = vectorstore.as_retriever(
        search_type   = "mmr",
        search_kwargs = {"k": k, "fetch_k": FETCH_K},
    )
    return retriever, vectorstore


# ─────────────────────────────────────────────────────────────────────
# CORE RETRIEVAL — L2 distance threshold
# ─────────────────────────────────────────────────────────────────────
def retrieve_with_scores(
    vectorstore,
    query:     str,
    k:         int   = TOP_K,
    threshold: float = RELEVANCE_THRESHOLD,
    filename:  str   = None,       # optional: restrict search to one PDF
):
    """
    Two-stage ChromaFS retrieval:
      Stage 1 — Metadata filter: restrict to specific file if provided
      Stage 2 — Vector search:   L2 distance, keep chunks < threshold

    L2 distance (lower = more similar):
      0.0  = identical
      <0.5 = relevant
      >1.0 = unrelated / noise

    Returns:
        (docs, below_threshold)
        docs            — list of Document objects that passed
        below_threshold — True if nothing passed the threshold
    """
    where = {"filename": filename} if filename else None

    docs_and_scores = vectorstore.similarity_search_with_score(
        query,
        k     = k,
        filter = where,
    )

    print(f"[ChromaFS] L2 scores: {[round(s, 3) for _, s in docs_and_scores]}")

    relevant = [doc for doc, score in docs_and_scores if score < threshold]

    if not relevant:
        print(f"[ChromaFS] no chunks below L2={threshold} — rejected")
        return [], True

    print(f"[ChromaFS] {len(relevant)}/{len(docs_and_scores)} chunks passed")
    return relevant, False


# ─────────────────────────────────────────────────────────────────────
# CHROMAFS VIRTUAL FILESYSTEM OPERATIONS
# ─────────────────────────────────────────────────────────────────────

def list_files(vectorstore) -> list[str]:
    """
    ChromaFS: ls /
    Returns all unique PDF filenames in the index.
    """
    results = vectorstore._collection.get(include=["metadatas"])
    filenames = sorted({m["filename"] for m in results["metadatas"] if "filename" in m})
    return filenames


def list_pages(vectorstore, filename: str) -> list[int]:
    """
    ChromaFS: ls /<filename>
    Returns all page numbers indexed for a given PDF, sorted.
    """
    results = vectorstore._collection.get(
        where   = {"filename": filename},
        include = ["metadatas"],
    )
    pages = sorted({m["page"] for m in results["metadatas"] if "page" in m})
    return pages


def cat_page(vectorstore, filename: str, page: int) -> str:
    """
    ChromaFS: cat /<filename>/page_<n>
    Reassembles a full PDF page from its chunks (sorted by chunk_index).
    This is the ChromaFS page reassembly pattern.
    """
    results = vectorstore._collection.get(
        where   = {"$and": [{"filename": filename}, {"page": page}]},
        include = ["documents", "metadatas"],
    )

    if not results["documents"]:
        return f"No content found for {filename} page {page}."

    # Sort chunks by chunk_index to preserve reading order
    paired = sorted(
        zip(results["documents"], results["metadatas"]),
        key=lambda x: x[1].get("chunk_index", 0),
    )

    return "\n".join(doc for doc, _ in paired)


def chroma_grep(vectorstore, query: str, filename: str = None, k: int = TOP_K) -> list:
    """
    ChromaFS: grep <query> [/<filename>]
    Two-stage search:
      Stage 1 — Chroma metadata filter (restrict to file if given)
      Stage 2 — Vector similarity search within that filtered set
    Returns raw (doc, score) pairs without threshold filtering.
    """
    where = {"filename": filename} if filename else None

    return vectorstore.similarity_search_with_score(
        query,
        k      = k,
        filter = where,
    )


# ─────────────────────────────────────────────────────────────────────
# TEST
# ─────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    vs = load_vectorstore()

    print("\n── list_files() ──")
    files = list_files(vs)
    for f in files[:5]:
        print(f"  {f}")

    print(f"\n── list_pages('{files[0]}') ──")
    pages = list_pages(vs, files[0])
    print(f"  Pages: {pages[:10]}...")

    print(f"\n── cat_page('{files[0]}', {pages[0]}) ──")
    content = cat_page(vs, files[0], pages[0])
    print(content[:400])

    print("\n── retrieve_with_scores('Who was Akbar?') ──")
    docs, below = retrieve_with_scores(vs, "Who was Akbar?")
    for i, doc in enumerate(docs, 1):
        print(f"  [{i}] {doc.metadata.get('filename')} p{doc.metadata.get('page')}: {doc.page_content[:80]}...")