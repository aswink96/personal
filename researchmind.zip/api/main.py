# api/main.py
# ─────────────────────────────────────────────────────────────────────
# PURPOSE: FastAPI server — history-aware RAG + agent, with PostgreSQL.
#
# Session flow:
#   1. Frontend generates a session_id (UUID) on page load
#   2. Every /ask/stream request sends question + session_id
#   3. API loads chat history from Postgres
#   4. Chain runs: contextualize → retrieve → generate
#   5. Q&A pair written to Postgres permanently
#
# Endpoints:
#   POST   /ask/stream            → streams RAG chain tokens
#   POST   /ask                   → full RAG chain answer (JSON)
#   POST   /agent/ask             → full agent answer (tool-calling, JSON)
#   POST   /agent/ask/stream      → streams agent answer tokens
#   GET    /session/{id}/history  → load full history for a session
#   DELETE /session/{id}          → clear session (new chat)
#   GET    /sessions              → list all sessions
#   GET    /health                → liveness check
#
# Run: uvicorn api.main:app --reload --port 8000
# ─────────────────────────────────────────────────────────────────────

import os
import sys
import uuid
from contextlib import asynccontextmanager

import psycopg2
import psycopg2.extras
from fastapi import FastAPI, HTTPException
from fastapi.responses import StreamingResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from rag_chain import build_chain_from_vectorstore
from retriever import load_retriever
from agent.planner import build_agent, run_agent
from config.settings import POSTGRES_URL, MAX_HISTORY_TURNS


# ─────────────────────────────────────────────────────────────────────
# DB HELPERS
# ─────────────────────────────────────────────────────────────────────
def get_pg_conn():
    return psycopg2.connect(POSTGRES_URL)


def ensure_pg_tables():
    """Creates tables if they don't exist yet."""
    conn = get_pg_conn()
    with conn:
        with conn.cursor() as cur:
            cur.execute("""
                CREATE TABLE IF NOT EXISTS sessions (
                    session_id  TEXT PRIMARY KEY,
                    created_at  TIMESTAMPTZ DEFAULT NOW(),
                    last_active TIMESTAMPTZ DEFAULT NOW()
                );
            """)
            cur.execute("""
                CREATE TABLE IF NOT EXISTS messages (
                    id          SERIAL PRIMARY KEY,
                    session_id  TEXT NOT NULL REFERENCES sessions(session_id) ON DELETE CASCADE,
                    role        TEXT NOT NULL,
                    content     TEXT NOT NULL,
                    created_at  TIMESTAMPTZ DEFAULT NOW()
                );
            """)
    conn.close()


# ─────────────────────────────────────────────────────────────────────
# HISTORY HELPERS
# ─────────────────────────────────────────────────────────────────────
def load_history(session_id: str) -> list[dict]:
    """Loads the last MAX_HISTORY_TURNS Q&A pairs from Postgres."""
    conn = get_pg_conn()
    try:
        with conn.cursor(cursor_factory=psycopg2.extras.DictCursor) as cur:
            cur.execute(
                """
                SELECT role, content FROM messages
                WHERE session_id = %s
                ORDER BY created_at ASC
                """,
                (session_id,)
            )
            history = [{"role": row["role"], "content": row["content"]} for row in cur.fetchall()]
        # Keep only the last MAX_HISTORY_TURNS turns (each turn = 2 messages)
        max_msgs = MAX_HISTORY_TURNS * 2
        return history[-max_msgs:]
    finally:
        conn.close()


def save_messages(session_id: str, question: str, answer: str):
    """Saves a Q&A pair to Postgres, creating the session row if needed."""
    conn = get_pg_conn()
    try:
        with conn:
            with conn.cursor() as cur:
                # Upsert session row
                cur.execute("""
                    INSERT INTO sessions (session_id, last_active)
                    VALUES (%s, NOW())
                    ON CONFLICT (session_id)
                    DO UPDATE SET last_active = NOW()
                """, (session_id,))
                # Insert user message and assistant answer
                cur.executemany(
                    "INSERT INTO messages (session_id, role, content) VALUES (%s, %s, %s)",
                    [
                        (session_id, "user",      question),
                        (session_id, "assistant", answer),
                    ]
                )
    finally:
        conn.close()


# ─────────────────────────────────────────────────────────────────────
# APP STARTUP
# ─────────────────────────────────────────────────────────────────────
# Vectorstore is loaded once (expensive). A fresh LLM + chain is built
# per request to avoid httpx client-closed errors in langchain-ollama.
_state: dict = {}


def check_connections():
    """Verify Postgres is reachable before starting. Fail fast with a clear message."""
    try:
        conn = get_pg_conn()
        conn.close()
        print("✅ PostgreSQL connected")
    except Exception as e:
        raise RuntimeError(
            f"\n\n❌ Cannot connect to PostgreSQL at {POSTGRES_URL}\n"
            f"   Make sure Postgres is running and the database exists.\n"
            f"   Create it with:  createdb rag_pipeline\n"
            f"   Error: {e}\n"
        )


@asynccontextmanager
async def lifespan(app: FastAPI):
    check_connections()
    print("Initialising Postgres tables...")
    ensure_pg_tables()
    print("Loading vectorstore...")
    _, vectorstore = load_retriever()
    _state["vectorstore"] = vectorstore
    print("Building agent...")
    _state["agent"] = build_agent(vectorstore)
    print("Ready.")
    yield
    _state.clear()


app = FastAPI(
    title="test_rag_pipeline API",
    description="History-aware RAG pipeline with PostgreSQL memory.",
    version="2.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

_frontend_dir = os.path.join(os.path.dirname(__file__), "..", "frontend")
if os.path.isdir(_frontend_dir):
    app.mount("/static", StaticFiles(directory=_frontend_dir), name="static")

    @app.get("/", include_in_schema=False)
    def serve_ui():
        return FileResponse(os.path.join(_frontend_dir, "index.html"))


# ─────────────────────────────────────────────────────────────────────
# REQUEST / RESPONSE MODELS
# ─────────────────────────────────────────────────────────────────────
class QuestionRequest(BaseModel):
    question:   str = Field(..., min_length=1)
    session_id: str = Field(default_factory=lambda: str(uuid.uuid4()))


class AnswerResponse(BaseModel):
    question:   str
    answer:     str
    session_id: str


# ─────────────────────────────────────────────────────────────────────
# ENDPOINTS
# ─────────────────────────────────────────────────────────────────────
@app.get("/health")
def health():
    return {"status": "ok", "vectorstore_loaded": bool(_state)}


@app.post("/ask", response_model=AnswerResponse)
def ask(req: QuestionRequest):
    """Full (non-streaming) answer with session memory."""
    if not _state:
        raise HTTPException(status_code=503, detail="Vectorstore not loaded yet.")
    try:
        history = load_history(req.session_id)
        chain   = build_chain_from_vectorstore(_state["vectorstore"])
        answer  = chain.invoke({"question": req.question, "history": history})
        save_messages(req.session_id, req.question, answer)
        return AnswerResponse(question=req.question, answer=answer, session_id=req.session_id)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/ask/stream")
def ask_stream(req: QuestionRequest):
    """
    Streams tokens via plain text. Saves Q&A to Postgres after stream completes.
    First line sent is always: __session__:<id>
    so the frontend can persist the session_id.
    """
    if not _state:
        raise HTTPException(status_code=503, detail="Vectorstore not loaded yet.")

    history = load_history(req.session_id)
    chain   = build_chain_from_vectorstore(_state["vectorstore"])

    def token_generator():
        yield f"__session__:{req.session_id}\n"
        answer = ""
        try:
            for token in chain.stream({"question": req.question, "history": history}):
                answer += token
                yield token
        except Exception as e:
            yield f"\n[ERROR: {e}]"
        finally:
            if answer:
                save_messages(req.session_id, req.question, answer)

    return StreamingResponse(token_generator(), media_type="text/plain")


@app.get("/session/{session_id}/history")
def get_history(session_id: str):
    """Returns the full message history for a session."""
    history = load_history(session_id)
    return {"session_id": session_id, "history": history}


@app.delete("/session/{session_id}")
def delete_session(session_id: str):
    """Deletes a session and all its messages from Postgres."""
    conn = get_pg_conn()
    try:
        with conn:
            with conn.cursor() as cur:
                cur.execute("DELETE FROM sessions WHERE session_id = %s", (session_id,))
    finally:
        conn.close()
    return {"status": "cleared", "session_id": session_id}


@app.get("/sessions")
def list_sessions():
    """Lists all sessions with their last active timestamp."""
    conn = get_pg_conn()
    try:
        with conn.cursor(cursor_factory=psycopg2.extras.DictCursor) as cur:
            cur.execute(
                "SELECT session_id, created_at, last_active FROM sessions ORDER BY last_active DESC"
            )
            return {"sessions": [dict(r) for r in cur.fetchall()]}
    finally:
        conn.close()


# ─────────────────────────────────────────────────────────────────────
# AGENT ENDPOINTS
# The agent uses tool-calling (rag_search + arxiv_search) to decide
# what to retrieve before generating an answer.
# ─────────────────────────────────────────────────────────────────────
@app.post("/agent/ask", response_model=AnswerResponse)
def agent_ask(req: QuestionRequest):
    """Full agent answer with tool-calling (rag_search + arxiv_search)."""
    if not _state:
        raise HTTPException(status_code=503, detail="Agent not ready.")
    try:
        history = load_history(req.session_id)
        # Build a fresh agent per request (avoids httpx client-closed errors)
        agent = build_agent(_state["vectorstore"])
        answer = run_agent(agent, req.question, history)
        save_messages(req.session_id, req.question, answer)
        return AnswerResponse(question=req.question, answer=answer, session_id=req.session_id)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/agent/ask/stream")
async def agent_ask_stream(req: QuestionRequest):
    """
    Streams agent answer tokens via plain text.
    Uses astream_events to emit only final-answer tokens (not intermediate tool calls).
    First line: __session__:<id>
    """
    if not _state:
        raise HTTPException(status_code=503, detail="Agent not ready.")

    history = load_history(req.session_id)
    from langchain_core.messages import HumanMessage, AIMessage, SystemMessage
    from agent.planner import SYSTEM_PROMPT, _make_llm
    from langchain.agents import create_agent
    from agent.tools import rag_search, arxiv_search

    messages = [SystemMessage(content=SYSTEM_PROMPT)]
    for msg in history:
        if msg["role"] == "user":
            messages.append(HumanMessage(content=msg["content"]))
        else:
            messages.append(AIMessage(content=msg["content"]))
    messages.append(HumanMessage(content=req.question))

    agent = create_agent(
        model=_make_llm(),
        tools=[rag_search, arxiv_search],
        system_prompt=SYSTEM_PROMPT,
    )

    async def generate():
        yield f"__session__:{req.session_id}\n"
        answer = ""
        try:
            async for event in agent.astream_events({"messages": messages}, version="v2"):
                if event["event"] != "on_chat_model_stream":
                    continue
                chunk = event["data"]["chunk"]
                # Skip tool-call chunks; emit only final-answer text
                if getattr(chunk, "tool_call_chunks", None):
                    continue
                if chunk.content:
                    answer += chunk.content
                    yield chunk.content
        except Exception as e:
            yield f"\n[ERROR: {e}]"
        finally:
            if answer:
                save_messages(req.session_id, req.question, answer)

    return StreamingResponse(generate(), media_type="text/plain")